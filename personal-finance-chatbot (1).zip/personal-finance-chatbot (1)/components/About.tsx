import React from 'react';
import { InfoIcon, ShieldCheckIcon } from './icons';

const About: React.FC = () => {
  return (
    <div className="flex-grow p-6 overflow-y-auto bg-transparent custom-scrollbar">
        <div className="max-w-4xl mx-auto text-center">
            <h1 className="text-4xl font-bold text-accent mb-4 text-shadow-md">FinBot</h1>
            <p className="text-lg text-text-primary mb-10 text-shadow">
                Your Intelligent Personal Finance Assistant
            </p>

            <div className="space-y-8 text-left bg-background-secondary/85 backdrop-blur-md p-8 rounded-xl border border-text-secondary/50">
                {/* Powered by Section */}
                <div>
                    <div className="flex items-center mb-3">
                        <InfoIcon className="w-7 h-7 text-accent mr-3" />
                        <h2 className="text-2xl font-bold text-text-primary text-shadow-md">Powered by IBM & Google AI</h2>
                    </div>
                    <p className="text-text-secondary leading-relaxed text-shadow">
                        This application leverages the power of cutting-edge artificial intelligence to provide you with personalized financial insights. Our core conversational and analytical capabilities are powered by state-of-the-art models, including IBM's Granite series and Google's Gemini, ensuring you receive accurate, relevant, and context-aware guidance.
                    </p>
                </div>

                {/* Privacy Section */}
                <div>
                    <div className="flex items-center mb-3">
                        <ShieldCheckIcon className="w-7 h-7 text-success mr-3" />
                        <h2 className="text-2xl font-bold text-text-primary text-shadow-md">Our Commitment to Your Privacy</h2>
                    </div>
                    <p className="text-text-secondary leading-relaxed text-shadow">
                        We take your data privacy and security seriously. Your conversations and financial data are handled with the utmost care. We do not sell your personal information to third parties. All data is encrypted in transit and at rest. This application is a demonstration project, and no real financial data is stored or processed.
                    </p>
                </div>
            </div>
        </div>
    </div>
  );
};

export default About;