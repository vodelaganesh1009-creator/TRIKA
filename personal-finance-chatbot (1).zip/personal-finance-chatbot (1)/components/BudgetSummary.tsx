import React from 'react';
import { LightBulbIcon } from './icons';

// --- Mock Data ---
const budgetData = {
  totalBudget: 40000,
  totalSpending: 32450,
  categories: [
    { name: 'Bills & Utilities', spent: 12500, budget: 13000, colorVar: 'var(--color-chart-1)' },
    { name: 'Food & Dining', spent: 8200, budget: 10000, colorVar: 'var(--color-chart-2)' },
    { name: 'Shopping', spent: 4500, budget: 6000, colorVar: 'var(--color-chart-3)' },
    { name: 'Travel', spent: 3250, budget: 5000, colorVar: 'var(--color-chart-4)' },
    { name: 'Other', spent: 4000, budget: 6000, colorVar: 'var(--color-chart-5)' },
  ],
};

const aiRecommendation = "Your budget is well-managed this month. You have extra room in 'Travel' and 'Shopping'. Consider moving some of this surplus to your savings goals to reach them faster!";

// --- Sub-components ---

const DonutChart: React.FC<{ data: typeof budgetData.categories, total: number }> = ({ data, total }) => {
    const radius = 80;
    const strokeWidth = 25;
    const circumference = 2 * Math.PI * radius;
    let accumulatedPercentage = 0;

    return (
        <div className="relative w-56 h-56">
            <svg viewBox="0 0 200 200" className="transform -rotate-90">
                {data.map((item, index) => {
                    const percentage = (item.spent / total) * 100;
                    const strokeDashoffset = circumference - (accumulatedPercentage / 100) * circumference;
                    const strokeDasharray = `${(percentage / 100) * circumference} ${circumference}`;
                    accumulatedPercentage += percentage;

                    return (
                        <circle
                            key={index}
                            r={radius}
                            cx="100"
                            cy="100"
                            fill="transparent"
                            style={{ stroke: item.colorVar }}
                            strokeWidth={strokeWidth}
                            strokeDasharray={strokeDasharray}
                            strokeDashoffset={strokeDashoffset}
                            strokeLinecap="butt"
                        />
                    );
                })}
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
                 <span className="text-3xl font-bold text-text-primary text-shadow-md">₹{total.toLocaleString('en-IN')}</span>
                 <span className="text-sm text-text-secondary text-shadow">Total Spent</span>
            </div>
        </div>
    );
};

const BudgetCategory: React.FC<{ item: typeof budgetData.categories[0] }> = ({ item }) => {
    const percentage = (item.spent / item.budget) * 100;
    return (
        <div>
            <div className="flex justify-between items-center mb-1">
                <span className="font-medium text-text-primary text-shadow">{item.name}</span>
                <span className="text-sm text-text-secondary">
                    ₹{item.spent.toLocaleString('en-IN')} / ₹{item.budget.toLocaleString('en-IN')}
                </span>
            </div>
            <div className="w-full bg-background-tertiary/70 rounded-full h-2">
                <div style={{ width: `${percentage}%`, backgroundColor: item.colorVar, height: '100%', borderRadius: '9999px' }}></div>
            </div>
        </div>
    );
};


const BudgetSummary: React.FC = () => {
  return (
    <div className="flex-grow p-6 overflow-y-auto bg-transparent custom-scrollbar">
        <h1 className="text-3xl font-bold text-text-primary mb-6 text-shadow-md">Budget Summary</h1>
        <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
            {/* Left Column: Chart and AI */}
            <div className="lg:col-span-2 flex flex-col gap-6">
                <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50 flex flex-col items-center justify-center">
                    <h2 className="text-xl font-bold text-text-primary mb-4 self-start text-shadow-md">Monthly Spending</h2>
                    <DonutChart data={budgetData.categories} total={budgetData.totalSpending} />
                </div>
                 <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50">
                    <h2 className="text-xl font-bold text-text-primary mb-4 flex items-center gap-2 text-shadow-md">
                        <LightBulbIcon className="w-6 h-6 text-warning" />
                        AI Recommendations
                    </h2>
                    <p className="text-text-secondary leading-relaxed text-shadow">{aiRecommendation}</p>
                </div>
            </div>

            {/* Right Column: Categories */}
            <div className="lg:col-span-3 bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50">
                 <h2 className="text-xl font-bold text-text-primary mb-4 text-shadow-md">Category Breakdown</h2>
                 <div className="space-y-5">
                    {budgetData.categories.map(category => (
                        <BudgetCategory key={category.name} item={category} />
                    ))}
                 </div>
            </div>
        </div>
    </div>
  );
};

export default BudgetSummary;