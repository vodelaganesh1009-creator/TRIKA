import React, { useState, useEffect, useCallback, useRef } from 'react';
import { Message, Sender } from '../types';
import { GREETING_MESSAGES } from '../constants';
import { getBotResponse, resetChatForPersona } from '../services/geminiService';
import ChatWindow from './ChatWindow';
import MessageInput from './MessageInput';
import { usePersona } from '../contexts/PersonaContext';

// Helper hook to get the previous value of a prop or state.
const usePrevious = <T,>(value: T): T | undefined => {
    // FIX: The `useRef` hook with a generic type requires an initial value.
    // Providing `undefined` resolves the "Expected 1 arguments, but got 0" error.
    const ref = useRef<T | undefined>(undefined);
    useEffect(() => {
        ref.current = value;
    });
    return ref.current;
};


const ChatView: React.FC = () => {
  const { persona } = usePersona();
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const prevPersona = usePrevious(persona);

  const initializeChat = useCallback(() => {
    setMessages([
      {
        id: crypto.randomUUID(),
        text: GREETING_MESSAGES[persona],
        sender: Sender.Bot,
      },
    ]);
  }, [persona]);

  useEffect(() => {
    if (prevPersona && prevPersona !== persona) {
        resetChatForPersona(prevPersona);
    }
    initializeChat();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [persona]);

  const handleSendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return;

    const userMessage: Message = {
      id: crypto.randomUUID(),
      text,
      sender: Sender.User,
    };

    setMessages((prevMessages) => [...prevMessages, userMessage]);
    setIsLoading(true);

    try {
      const botResponseText = await getBotResponse(text, persona);
      const botMessage: Message = {
        id: crypto.randomUUID(),
        text: botResponseText,
        sender: Sender.Bot,
      };
      setMessages((prevMessages) => [...prevMessages, botMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: crypto.randomUUID(),
        text: 'Sorry, something went wrong. Please try again.',
        sender: Sender.Bot,
      };
      setMessages((prevMessages) => [...prevMessages, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="h-full w-full flex flex-col font-sans rounded-2xl bg-background-secondary/85 backdrop-blur-md border border-text-secondary/50 overflow-hidden">
      <ChatWindow messages={messages} isLoading={isLoading} />
      <MessageInput onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
};

export default ChatView;