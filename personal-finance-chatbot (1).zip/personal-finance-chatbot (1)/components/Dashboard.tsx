import React from 'react';
import { WalletIcon, TrendingUpIcon, TrendingDownIcon, PiggyBankIcon, LightBulbIcon } from './icons';

// --- Mock Data ---
const keyMetrics = {
  balance: '₹1,50,234',
  income: '₹55,000',
  expenses: '₹32,450',
  savingsRate: '41%',
};

const spendingData = [
  { category: 'Bills & Utilities', amount: 12500, color: 'bg-chart-1' },
  { category: 'Food & Dining', amount: 8200, color: 'bg-chart-2' },
  { category: 'Shopping', amount: 4500, color: 'bg-chart-3' },
  { category: 'Travel', amount: 3250, color: 'bg-chart-4' },
  { category: 'Other', amount: 4000, color: 'bg-chart-5' },
];

const totalSpending = spendingData.reduce((sum, item) => sum + item.amount, 0);

const recentTransactions = [
    { id: 1, description: 'Salary Deposit', date: 'Oct 25, 2023', amount: 55000, type: 'income' },
    { id: 2, description: 'Netflix Subscription', date: 'Oct 24, 2023', amount: -649, type: 'expense' },
    { id: 3, description: 'Zomato Order', date: 'Oct 23, 2023', amount: -450, type: 'expense' },
    { id: 4, description: 'Freelance Project', date: 'Oct 22, 2023', amount: 8000, type: 'income' },
];

const aiSummary = "You're on track this month! Your savings rate is excellent. However, spending on 'Food & Dining' is slightly higher than last month. Consider setting a budget for this category to boost your savings further.";

// --- Sub-components ---
const MetricCard: React.FC<{ icon: React.ElementType; title: string; value: string; }> = ({ icon: Icon, title, value }) => (
  <div className="bg-background-secondary/85 backdrop-blur-md p-5 rounded-xl flex items-center space-x-4 border border-text-secondary/50">
    <div className="bg-background-primary/80 p-3 rounded-full">
        <Icon className="w-6 h-6 text-accent" />
    </div>
    <div>
      <p className="text-sm text-text-secondary text-shadow">{title}</p>
      <p className="text-2xl font-bold text-text-primary text-shadow-md">{value}</p>
    </div>
  </div>
);

const SpendingBar: React.FC<{ category: string; amount: number; percentage: number; color: string; }> = ({ category, amount, percentage, color }) => (
    <div>
        <div className="flex justify-between items-center mb-1">
            <span className="text-sm text-text-primary text-shadow">{category}</span>
            <span className="text-sm font-medium text-text-secondary">₹{amount.toLocaleString('en-IN')}</span>
        </div>
        <div className="w-full bg-background-tertiary/70 rounded-full h-2.5">
            <div className={color} style={{ width: `${percentage}%`, height: '100%', borderRadius: '9999px' }}></div>
        </div>
    </div>
);


const Dashboard: React.FC = () => {
  return (
    <div className="flex-grow p-6 overflow-y-auto bg-transparent custom-scrollbar">
        <h1 className="text-3xl font-bold text-text-primary mb-6 text-shadow-md">Welcome back, Alex!</h1>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <MetricCard icon={WalletIcon} title="Total Balance" value={keyMetrics.balance} />
            <MetricCard icon={TrendingUpIcon} title="Monthly Income" value={keyMetrics.income} />
            <MetricCard icon={TrendingDownIcon} title="Monthly Expenses" value={keyMetrics.expenses} />
            <MetricCard icon={PiggyBankIcon} title="Savings Rate" value={keyMetrics.savingsRate} />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Left Column: Spending & Transactions */}
            <div className="lg:col-span-2 flex flex-col gap-6">
                {/* Spending Summary */}
                <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50">
                    <h2 className="text-xl font-bold text-text-primary mb-4 text-shadow-md">Spending Summary</h2>
                    <div className="space-y-4">
                        {spendingData.map(item => (
                            <SpendingBar 
                                key={item.category}
                                category={item.category} 
                                amount={item.amount} 
                                percentage={(item.amount / totalSpending) * 100} 
                                color={item.color}
                            />
                        ))}
                    </div>
                </div>

                 {/* Recent Transactions */}
                 <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50">
                    <h2 className="text-xl font-bold text-text-primary mb-4 text-shadow-md">Recent Transactions</h2>
                    <ul className="divide-y divide-text-secondary/50">
                        {recentTransactions.map(tx => (
                            <li key={tx.id} className="flex justify-between items-center py-3">
                                <div>
                                    <p className="font-medium text-text-primary text-shadow">{tx.description}</p>
                                    <p className="text-sm text-text-secondary">{tx.date}</p>
                                </div>
                                <p className={`font-semibold ${tx.type === 'income' ? 'text-success' : 'text-error'}`}>
                                    {tx.type === 'income' ? '+' : '-'}₹{Math.abs(tx.amount).toLocaleString('en-IN')}
                                </p>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            {/* Right Column: AI Summary */}
            <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50 flex flex-col">
                <h2 className="text-xl font-bold text-text-primary mb-4 text-shadow-md">AI Financial Health</h2>
                <div className="flex-grow flex flex-col items-center justify-center bg-background-primary/50 p-6 rounded-lg text-center">
                    <LightBulbIcon className="w-10 h-10 text-warning mb-4" />
                    <p className="text-text-secondary leading-relaxed text-shadow">{aiSummary}</p>
                </div>
            </div>
        </div>
    </div>
  );
};

export default Dashboard;