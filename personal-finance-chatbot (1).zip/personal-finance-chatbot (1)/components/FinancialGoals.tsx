import React from 'react';
import { LightBulbIcon, PlusCircleIcon } from './icons';

// --- Mock Data ---
const goals = [
  {
    name: 'Vacation to Goa',
    current: 7500,
    target: 20000,
    color: 'bg-chart-3',
    aiTip: 'Try using a travel booking site\'s price alert feature to find the cheapest flights.'
  },
  {
    name: 'New Laptop',
    current: 32000,
    target: 80000,
    color: 'bg-chart-4',
    aiTip: 'Look for student discounts or refurbished models from official sellers to save money.'
  },
  {
    name: 'Emergency Fund',
    current: 45000,
    target: 100000,
    color: 'bg-chart-1',
    aiTip: 'Automate a small transfer to this fund every payday. Consistency is key!'
  },
];


// --- Sub-components ---
const GoalCard: React.FC<{ goal: typeof goals[0] }> = ({ goal }) => {
    const progress = (goal.current / goal.target) * 100;

    return (
        <div className="bg-background-secondary/85 backdrop-blur-md p-5 rounded-xl border border-text-secondary/50">
            {/* Header */}
            <div className="flex justify-between items-start mb-3">
                <div>
                    <h3 className="text-lg font-bold text-text-primary text-shadow-md">{goal.name}</h3>
                    <p className="text-sm text-text-secondary">Target: ₹{goal.target.toLocaleString('en-IN')}</p>
                </div>
                <span className="text-lg font-bold text-accent text-shadow-md">{Math.round(progress)}%</span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-background-tertiary/70 rounded-full h-2.5 mb-2">
                <div className={`${goal.color}`} style={{ width: `${progress}%`, height: '100%', borderRadius: '9999px' }}></div>
            </div>
            <p className="text-sm text-right text-text-primary text-shadow">Saved: ₹{goal.current.toLocaleString('en-IN')}</p>
            
            {/* AI Tip */}
            <div className="mt-4 bg-background-primary/50 p-3 rounded-lg flex items-start space-x-2">
                <LightBulbIcon className="w-5 h-5 text-warning flex-shrink-0 mt-0.5" />
                <p className="text-xs text-text-secondary">{goal.aiTip}</p>
            </div>
        </div>
    );
};

const FinancialGoals: React.FC = () => {
  return (
    <div className="flex-grow p-6 overflow-y-auto bg-transparent custom-scrollbar">
        <div className="flex justify-between items-center mb-6">
            <h1 className="text-3xl font-bold text-text-primary text-shadow-md">Financial Goals</h1>
            <button className="flex items-center space-x-2 bg-primary text-white font-semibold px-4 py-2 rounded-lg hover:bg-opacity-90 transition-colors">
                <PlusCircleIcon className="w-5 h-5" />
                <span>Add New Goal</span>
            </button>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
            {goals.map(goal => (
                <GoalCard key={goal.name} goal={goal} />
            ))}
        </div>
    </div>
  );
};

export default FinancialGoals;