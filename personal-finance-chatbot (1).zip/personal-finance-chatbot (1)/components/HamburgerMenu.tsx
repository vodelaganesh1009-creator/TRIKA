import React from 'react';
import { 
    DashboardIcon, ChatbotIcon, BudgetIcon, GoalsIcon, LearnIcon, 
    SettingsIcon, ReportsIcon, InfoIcon, LogoutIcon, ProfileIcon, HamburgerIcon
} from './icons';

interface HamburgerMenuProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (page: string) => void;
  currentPage: string;
}

// A component to render the menu item with an icon
const MenuItem: React.FC<{ icon: React.ElementType; text: string }> = ({ icon: Icon, text }) => (
  <div className="flex items-center space-x-4">
    <Icon className="w-5 h-5 text-text-secondary group-hover:text-accent transition-colors" />
    <span>{text}</span>
  </div>
);

// Define menu items with their corresponding pages and icons
const menuItems = [
  { page: 'Dashboard', icon: DashboardIcon },
  { page: 'Chatbot / Ask AI', icon: ChatbotIcon },
  { page: 'Budget Summary', icon: BudgetIcon },
  { page: 'Financial Goals', icon: GoalsIcon },
  { page: 'Learn & Grow (Financial Literacy)', icon: LearnIcon },
  { page: 'Settings', icon: SettingsIcon },
  { page: 'Reports / History', icon: ReportsIcon },
];

const bottomMenuItems = [
    { page: 'About / IBM AI Info', icon: InfoIcon },
    { page: 'Log Out / Exit', icon: LogoutIcon },
];

const HamburgerMenu: React.FC<HamburgerMenuProps> = ({ isOpen, onClose, onNavigate, currentPage }) => {
  const handleNavigation = (page: string) => {
    onNavigate(page);
    onClose();
  };

  return (
      <aside
        className={`flex-shrink-0 transition-all duration-300 ease-in-out bg-background-secondary/95 backdrop-blur-md text-text-primary border-r border-text-secondary/50 h-full overflow-hidden ${
            isOpen ? 'w-80' : 'w-0 border-r-0'
        }`}
      >
        {/* Inner container prevents content from wrapping during animation */}
        <div className="w-80 h-full flex flex-col">
            {/* Header */}
            <div className="p-5 border-b border-text-secondary/50 flex items-center justify-between flex-shrink-0">
                <div className="flex items-center space-x-3">
                    <button 
                        onClick={onClose} 
                        className="p-2 -ml-2 rounded-full hover:bg-border/50 transition-colors"
                        aria-label="Close menu"
                    >
                        <HamburgerIcon className="w-6 h-6 text-text-primary" />
                    </button>
                    <h2 id="menu-title" className="text-xl font-bold text-accent text-shadow-md">
                        FinBot Menu
                    </h2>
                </div>
            </div>

            {/* Navigation */}
            <nav className="flex-grow p-3 overflow-y-auto custom-scrollbar">
            <ul className="space-y-1">
                {menuItems.map(({ page, icon }) => (
                <li key={page}>
                    <button
                    onClick={() => handleNavigation(page)}
                    className={`w-full text-left px-3 py-3 rounded-lg text-base font-medium transition-colors duration-200 flex items-center group ${
                        currentPage === page
                        ? 'bg-primary/20 text-secondary'
                        : 'text-text-primary hover:bg-border/50'
                    }`}
                    >
                    <MenuItem icon={icon} text={page} />
                    </button>
                </li>
                ))}
            </ul>
            </nav>
            
            {/* Bottom Section */}
            <div className="p-3 mt-auto flex-shrink-0">
            <ul className="space-y-1 border-t border-text-secondary/50 pt-2">
                {bottomMenuItems.map(({ page, icon }) => (
                    <li key={page}>
                        <button
                        onClick={() => handleNavigation(page)}
                        className={`w-full text-left px-3 py-3 rounded-lg text-base font-medium transition-colors duration-200 flex items-center group ${
                            currentPage === page
                            ? 'bg-primary/20 text-secondary'
                            : 'text-text-primary hover:bg-border/50'
                        }`}
                        >
                        <MenuItem icon={icon} text={page} />
                        </button>
                    </li>
                ))}
            </ul>

            {/* Profile Section */}
            <button
                onClick={() => handleNavigation('Profile / Personalization')}
                className={`w-full mt-4 p-3 bg-background-primary/50 rounded-lg text-left transition-colors duration-200 hover:bg-border/50 ${
                    currentPage === 'Profile / Personalization' ? 'ring-2 ring-primary' : ''
                }`}
                aria-label="Open Profile and Personalization page"
            >
                <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 rounded-full bg-primary flex items-center justify-center font-bold text-white">
                        AM
                    </div>
                    <div>
                        <p className="font-semibold text-text-primary text-shadow-md">Alex Morgan</p>
                        <p className="text-xs text-text-secondary">alex.morgan@example.com</p>
                    </div>
                </div>
            </button>
            </div>
        </div>
      </aside>
  );
};

export default HamburgerMenu;