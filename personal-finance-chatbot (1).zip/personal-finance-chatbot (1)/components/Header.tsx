import React from 'react';
import { HamburgerIcon } from './icons';

interface HeaderProps {
    onMenuClick: () => void;
}

const Header: React.FC<HeaderProps> = ({ onMenuClick }) => {
  return (
    <header className="relative bg-background-secondary/85 backdrop-blur-md p-5 flex items-center justify-center shadow-md z-10 border-b border-text-secondary/50">
        <button 
            onClick={onMenuClick} 
            className="absolute left-4 top-1/2 -translate-y-1/2 p-2 rounded-full hover:bg-border/50 transition-colors"
            aria-label="Toggle menu"
        >
            <HamburgerIcon className="w-6 h-6 text-text-primary" />
        </button>
        <div className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2">
            <h1 className="text-2xl font-bold text-accent text-shadow-md whitespace-nowrap">
                Personal Finance Chatbot
            </h1>
        </div>
    </header>
  );
};

export default Header;