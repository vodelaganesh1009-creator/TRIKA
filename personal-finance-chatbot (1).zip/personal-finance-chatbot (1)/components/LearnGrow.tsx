import React, { useState } from 'react';
import { LearnIcon } from './icons';

type Category = 'Student' | 'Professional';

// --- Mock Data ---
const articles = {
  Student: [
    { title: 'Smart Budgeting Hacks on a Student Income', excerpt: 'Learn how to make your money go further without sacrificing your social life.' },
    { title: 'Understanding Your First Credit Card', excerpt: 'A simple guide to credit scores, interest rates, and avoiding common pitfalls.' },
    { title: 'How to Start Saving for Short-Term Goals', excerpt: 'Practical tips for building a fund for spring break, a new laptop, or concert tickets.' },
    { title: 'Navigating Student Loans in India', excerpt: 'Everything you need to know about interest, repayment, and consolidation.' },
  ],
  Professional: [
    { title: 'Investing Basics: Stocks, Bonds, and Mutual Funds', excerpt: 'A clear introduction to the world of investing and building long-term wealth.' },
    { title: 'Tax-Saving Investments under Section 80C', excerpt: 'Maximize your returns by understanding the best tax-saving options available.' },
    { title: 'How to Build and Manage an Emergency Fund', excerpt: 'Why you need an emergency fund and how to calculate the right amount for your lifestyle.' },
    { title: 'A Beginner\'s Guide to Systematic Investment Plans (SIPs)', excerpt: 'Discover the power of disciplined investing through SIPs in mutual funds.' },
  ]
};

// --- Sub-components ---
const ArticleCard: React.FC<{ article: { title: string, excerpt: string } }> = ({ article }) => (
  <div className="bg-background-secondary/85 backdrop-blur-md p-5 rounded-xl border border-text-secondary/50 hover:border-primary/60 transition-colors group">
    <h3 className="text-lg font-bold text-text-primary mb-2 group-hover:text-accent text-shadow-md">{article.title}</h3>
    <p className="text-sm text-text-secondary mb-4 text-shadow">{article.excerpt}</p>
    <button className="font-semibold text-accent text-sm">Read More &rarr;</button>
  </div>
);

const LearnGrow: React.FC = () => {
  const [activeTab, setActiveTab] = useState<Category>('Student');

  return (
    <div className="flex-grow p-6 flex flex-col overflow-y-auto bg-transparent custom-scrollbar">
      <div className="flex items-center gap-3 mb-2">
        <LearnIcon className="w-8 h-8 text-accent" />
        <h1 className="text-3xl font-bold text-text-primary text-shadow-md">Learn & Grow</h1>
      </div>
      <p className="text-text-secondary mb-6 text-shadow">Bite-sized lessons to improve your financial knowledge.</p>

      {/* Tabs */}
      <div className="flex space-x-2 border-b border-text-secondary/50 mb-6">
        {(['Student', 'Professional'] as Category[]).map(tab => (
          <button
            key={tab}
            onClick={() => setActiveTab(tab)}
            className={`px-4 py-2 font-semibold transition-colors ${
              activeTab === tab 
                ? 'border-b-2 border-accent text-accent' 
                : 'text-text-secondary hover:text-text-primary'
            }`}
          >
            For {tab}s
          </button>
        ))}
      </div>

      {/* Articles Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {articles[activeTab].map((article, index) => (
          <ArticleCard key={index} article={article} />
        ))}
      </div>
    </div>
  );
};

export default LearnGrow;