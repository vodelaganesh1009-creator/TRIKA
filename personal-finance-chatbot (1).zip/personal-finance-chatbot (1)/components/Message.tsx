import React from 'react';
import { Message, Sender } from '../types';

interface MessageProps {
  message: Message;
}

const UserIcon = () => (
    <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" /></svg>
);

const BotIcon = () => (
    <svg className="w-6 h-6 text-accent" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" /></svg>
);

const MessageBubble: React.FC<MessageProps> = ({ message }) => {
  const isUser = message.sender === Sender.User;

  const containerClasses = isUser
    ? 'flex items-end justify-end space-x-2'
    : 'flex items-end space-x-2';

  const bubbleClasses = isUser
    ? 'bg-primary text-white'
    : 'bg-background-tertiary/85 backdrop-blur-sm text-text-primary';
    
  const avatarClasses = isUser
    ? 'w-10 h-10 bg-primary rounded-full flex-shrink-0 flex items-center justify-center order-2'
    : 'w-10 h-10 bg-background-tertiary/85 rounded-full flex-shrink-0 flex items-center justify-center order-1';

  const textContainerClasses = isUser ? 'order-1' : 'order-2';
  
  return (
    <div className={containerClasses}>
       <div className={avatarClasses}>
            {isUser ? <UserIcon /> : <BotIcon />}
       </div>
       <div className={textContainerClasses}>
            <div className={`${bubbleClasses} rounded-lg p-3 max-w-xs lg:max-w-md shadow-md`}>
                <p className="text-sm whitespace-pre-wrap text-shadow">{message.text}</p>
            </div>
       </div>
    </div>
  );
};

export default MessageBubble;