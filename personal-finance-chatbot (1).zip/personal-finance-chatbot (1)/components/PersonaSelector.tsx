import React from 'react';
import { Persona } from '../types';

interface PersonaSelectorProps {
  selectedPersona: Persona;
  onPersonaChange: (persona: Persona) => void;
}

const PersonaSelector: React.FC<PersonaSelectorProps> = ({ selectedPersona, onPersonaChange }) => {
  const personas = [Persona.Student, Persona.Professional];

  return (
    <div className="flex flex-col items-center space-y-2">
      <label className="text-sm font-medium text-text-secondary text-shadow">Select your profile:</label>
      <div className="flex space-x-2 rounded-lg bg-background-secondary/85 p-1">
        {personas.map((persona) => (
          <button
            key={persona}
            onClick={() => onPersonaChange(persona)}
            className={`px-4 py-2 text-sm font-semibold rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background-secondary focus:ring-primary ${
              selectedPersona === persona
                ? 'bg-primary text-white shadow-md'
                : 'bg-transparent text-text-primary hover:bg-background-tertiary/80'
            }`}
          >
            {persona}
          </button>
        ))}
      </div>
    </div>
  );
};

export default PersonaSelector;