import React from 'react';

interface PlaceholderProps {
  title: string;
}

const Placeholder: React.FC<PlaceholderProps> = ({ title }) => {
  return (
    <div className="flex-grow flex items-center justify-center text-text-secondary">
      <h2 className="text-3xl font-bold">{title}</h2>
    </div>
  );
};

export default Placeholder;