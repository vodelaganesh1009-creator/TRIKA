import React from 'react';
import { ReportsIcon, BudgetIcon, ChatbotIcon } from './icons';

// --- Mock Data ---
const historyItems = [
  {
    type: 'Chat Summary',
    title: 'Investment Strategy Discussion',
    date: 'Oct 25, 2023',
    icon: ChatbotIcon
  },
  {
    type: 'Budget Report',
    title: 'September 2023 Spending Analysis',
    date: 'Oct 1, 2023',
    icon: BudgetIcon
  },
  {
    type: 'Chat Summary',
    title: 'Tax Savings Inquiry',
    date: 'Sep 15, 2023',
    icon: ChatbotIcon
  },
  {
    type: 'Chat Summary',
    title: 'Student Loan Repayment Options',
    date: 'Sep 5, 2023',
    icon: ChatbotIcon
  },
  {
    type: 'Budget Report',
    title: 'August 2023 Spending Analysis',
    date: 'Sep 1, 2023',
    icon: BudgetIcon
  },
];


const ReportsHistory: React.FC = () => {
  return (
    <div className="flex-grow p-6 flex flex-col overflow-y-auto bg-transparent custom-scrollbar">
        <div className="flex items-center gap-3 mb-6">
            <ReportsIcon className="w-8 h-8 text-accent" />
            <h1 className="text-3xl font-bold text-text-primary text-shadow-md">Reports & History</h1>
        </div>
        
        <div className="bg-background-secondary/85 backdrop-blur-md rounded-xl border border-text-secondary/50">
            <ul className="divide-y divide-text-secondary/50">
                {historyItems.map((item, index) => (
                    <li key={index} className="flex items-center justify-between p-4 hover:bg-border/30 transition-colors duration-200">
                        <div className="flex items-center space-x-4">
                            <div className="bg-background-primary/80 p-3 rounded-full">
                                <item.icon className="w-6 h-6 text-accent" />
                            </div>
                            <div>
                                <p className="font-semibold text-text-primary text-shadow">{item.title}</p>
                                <p className="text-sm text-text-secondary">{item.type}</p>
                            </div>
                        </div>
                        <div className="text-right">
                             <p className="text-sm text-text-secondary">{item.date}</p>
                        </div>
                    </li>
                ))}
            </ul>
        </div>
    </div>
  );
};

export default ReportsHistory;