import React, { useState } from 'react';
import { SunIcon, MoonIcon, BellIcon, ShieldCheckIcon, SettingsIcon } from './icons';
import { useTheme, themes, ThemeName } from '../contexts/ThemeContext';

type AIBehavior = 'Simple' | 'Detailed';

// --- Sub-components ---
const SettingsRow: React.FC<{ icon: React.ElementType; title: string; description: string; children: React.ReactNode; }> = 
({ icon: Icon, title, description, children }) => (
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between py-4 border-b border-text-secondary/50 last:border-b-0">
        <div className="flex items-center space-x-4 mb-2 sm:mb-0">
            <Icon className="w-6 h-6 text-text-secondary" />
            <div>
                <h3 className="font-semibold text-text-primary text-shadow">{title}</h3>
                <p className="text-sm text-text-secondary">{description}</p>
            </div>
        </div>
        <div className="self-end sm:self-center">
            {children}
        </div>
    </div>
);

const Toggle: React.FC<{ enabled: boolean; setEnabled: (e: boolean) => void; }> = ({ enabled, setEnabled }) => (
  <button onClick={() => setEnabled(!enabled)} className={`relative inline-flex items-center h-6 rounded-full w-11 transition-colors ${enabled ? 'bg-primary' : 'bg-background-tertiary/80'}`}>
    <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${enabled ? 'translate-x-6' : 'translate-x-1'}`} />
  </button>
);


const Settings: React.FC = () => {
  const { theme, setTheme } = useTheme();
  const [aiBehavior, setAiBehavior] = useState<AIBehavior>('Simple');
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(false);

  return (
    <div className="flex-grow p-6 overflow-y-auto bg-transparent custom-scrollbar">
        <div className="flex items-center gap-3 mb-6">
            <SettingsIcon className="w-8 h-8 text-accent" />
            <h1 className="text-3xl font-bold text-text-primary text-shadow-md">Settings</h1>
        </div>

        <div className="max-w-4xl mx-auto">
            {/* Appearance Section */}
            <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl mb-6 border border-text-secondary/50">
                <h2 className="text-xl font-bold text-text-primary mb-2 text-shadow-md">Appearance</h2>
                <SettingsRow icon={theme.includes('light') ? SunIcon : MoonIcon} title="Theme" description="Choose your preferred color palette">
                    <div className="flex flex-wrap gap-2">
                        {Object.entries(themes).map(([key, name]) => (
                            <button
                                key={key}
                                onClick={() => setTheme(key as ThemeName)}
                                className={`px-3 py-1.5 text-sm font-semibold rounded-md transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-background-secondary focus:ring-primary ${
                                    theme === key
                                    ? 'bg-primary text-white shadow-lg'
                                    : 'bg-background-tertiary/80 text-text-secondary hover:bg-border/60'
                                }`}
                            >
                                {name}
                            </button>
                        ))}
                    </div>
                </SettingsRow>
            </div>

            {/* AI Settings Section */}
            <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl mb-6 border border-text-secondary/50">
                <h2 className="text-xl font-bold text-text-primary mb-2 text-shadow-md">AI Behavior</h2>
                 <SettingsRow icon={SettingsIcon} title="Reply Style" description="Choose how detailed AI responses should be">
                    <div className="flex space-x-1 rounded-lg bg-background-primary/70 p-1">
                        {(['Simple', 'Detailed'] as AIBehavior[]).map(b => (
                            <button
                                key={b}
                                onClick={() => setAiBehavior(b)}
                                className={`px-3 py-1 text-sm font-semibold rounded-md transition-colors ${
                                    aiBehavior === b ? 'bg-primary text-white' : 'text-text-primary hover:bg-background-tertiary/80'
                                }`}
                            >
                                {b}
                            </button>
                        ))}
                    </div>
                </SettingsRow>
            </div>

             {/* Notifications Section */}
            <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl mb-6 border border-text-secondary/50">
                <h2 className="text-xl font-bold text-text-primary mb-2 text-shadow-md">Notifications</h2>
                <SettingsRow icon={BellIcon} title="Push Notifications" description="Receive alerts for goals and summaries">
                    <Toggle enabled={pushNotifications} setEnabled={setPushNotifications} />
                </SettingsRow>
                <SettingsRow icon={BellIcon} title="Email Updates" description="Get weekly reports sent to your email">
                     <Toggle enabled={emailNotifications} setEnabled={setEmailNotifications} />
                </SettingsRow>
            </div>

             {/* Privacy Section */}
            <div className="bg-background-secondary/85 backdrop-blur-md p-6 rounded-xl border border-text-secondary/50">
                <h2 className="text-xl font-bold text-text-primary mb-2 text-shadow-md">Privacy</h2>
                <SettingsRow icon={ShieldCheckIcon} title="Privacy Policy" description="Read our data handling practices">
                    <button className="text-sm font-semibold text-accent hover:underline">View Policy</button>
                </SettingsRow>
            </div>
        </div>
    </div>
  );
};

export default Settings;