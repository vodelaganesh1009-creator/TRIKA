export default {
  plugins: []
}