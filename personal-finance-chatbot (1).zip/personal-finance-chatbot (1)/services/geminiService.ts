import { Persona } from '../types';
import { PERSONA_PROMPTS } from '../constants';

const chatInstances = new Map<Persona, any>();
const IBM_API_URL = 'http://localhost:5001';

function getChatInstance(persona: Persona): any {
  if (!chatInstances.has(persona)) {
    const newChat = {
      persona: persona,
      systemInstruction: PERSONA_PROMPTS[persona]
    };
    chatInstances.set(persona, newChat);
  }
  return chatInstances.get(persona)!;
}

async function callIBMGraniteAPI(userMessage: string, systemInstruction: string): Promise<string> {
  try {
    const response = await fetch(`${IBM_API_URL}/chat`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        message: userMessage,
        systemInstruction: systemInstruction
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    
    if (data.success) {
      return data.response;
    } else {
      throw new Error(data.error);
    }
  } catch (error) {
    console.error("IBM Granite API call failed:", error);
    throw error;
  }
}

export const getBotResponse = async (userMessage: string, persona: Persona): Promise<string> => {
  try {
    const chat = getChatInstance(persona);
    const systemInstruction = PERSONA_PROMPTS[persona];
    
    const result = await callIBMGraniteAPI(userMessage, systemInstruction);
    return result;
  } catch (error) {
    console.error("IBM Granite service error:", error);
    return "I'm sorry, I'm having trouble connecting right now. Please make sure the Python server is running on port 5001.";
  }
};

export const resetChatForPersona = (persona: Persona) => {
  chatInstances.delete(persona);
};